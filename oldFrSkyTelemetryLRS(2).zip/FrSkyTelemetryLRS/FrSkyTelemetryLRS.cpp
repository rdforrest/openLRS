/*
  FrSky Telemetry for Teensy 3.x and 328P based boards (e.g. Pro Mini, Nano, Uno)
  (c) Pawelsky 20150730
  Not for commercial use
*/

#include "FrSkyTelemetryLRS.h" 

FrSkyTelemetryLRS::FrSkyTelemetryLRS() : enabledSensors(SENSOR_NONE), cellIdx(0), frame1Time(0), frame2Time(0), frame3Time(0) {}

void FrSkyTelemetryLRS::begin(uint16_t id)
{
  //enable serial port for OpenLRSng data transfer
  if(id == SERIAL_HW)
  {
    port = &Serial;
    Serial.begin(9600);
  }

  if(id == SERIAL_1)
  {
#if defined(SERIAL_PORT_HARDWARE1)
    port = &Serial1;
    Serial1.begin(9600);
#else
    port = &Serial;
    Serial.begin(9600);
#endif
  }

  if(id == SERIAL_2)
  {
#if defined(SERIAL_PORT_HARDWARE2)
    port = &Serial2;
    Serial2.begin(9600);
#else
    port = &Serial;
    Serial.begin(9600);
#endif
  }
  
  if(id == SERIAL_3)
  {
#if defined(SERIAL_PORT_HARDWARE3)
    port = &Serial3;
    Serial3.begin(9600);
#else
    port = &Serial;
    Serial.begin(9600);
#endif
  }
  if (softSerial != NULL)
  {
    delete softSerial;
    softSerial = NULL;
  } 

#ifdef SOFT_SERIAL_PIN_2
  if(id == SOFT_SERIAL_PIN_2)
  {
    softSerial = new SoftwareSerial(SOFT_SERIAL_PIN_2, SOFT_SERIAL_PIN_2, false);
    port = softSerial;
    softSerial->begin(9600);
    pinMode(SOFT_SERIAL_PIN_2, OUTPUT);
  }
#endif
#ifdef SOFT_SERIAL_PIN_3
  if(id == SOFT_SERIAL_PIN_2)
  {
    softSerial = new SoftwareSerial(SOFT_SERIAL_PIN_2, SOFT_SERIAL_PIN_2, false);
    port = softSerial;
    softSerial->begin(9600);
    pinMode(SOFT_SERIAL_PIN_2, OUTPUT);
  }
#endif
#ifdef SOFT_SERIAL_PIN_4
  if(id == SOFT_SERIAL_PIN_2)
  {
    softSerial = new SoftwareSerial(SOFT_SERIAL_PIN_2, SOFT_SERIAL_PIN_2, false);
    port = softSerial;
    softSerial->begin(9600);
    pinMode(SOFT_SERIAL_PIN_2, OUTPUT);
  }
#endif
#ifdef SOFT_SERIAL_PIN_5
  if(id == SOFT_SERIAL_PIN_2)
  {
    softSerial = new SoftwareSerial(SOFT_SERIAL_PIN_2, SOFT_SERIAL_PIN_2, false);
    port = softSerial;
    softSerial->begin(9600);
    pinMode(SOFT_SERIAL_PIN_2, OUTPUT);
  }
#endif
#ifdef SOFT_SERIAL_PIN_6
  if(id == SOFT_SERIAL_PIN_2)
  {
    softSerial = new SoftwareSerial(SOFT_SERIAL_PIN_2, SOFT_SERIAL_PIN_2, false);
    port = softSerial;
    softSerial->begin(9600);
    pinMode(SOFT_SERIAL_PIN_2, OUTPUT);
  }
#endif
#ifdef SOFT_SERIAL_PIN_7
  if(id == SOFT_SERIAL_PIN_2)
  {
    softSerial = new SoftwareSerial(SOFT_SERIAL_PIN_2, SOFT_SERIAL_PIN_2, false);
    port = softSerial;
    softSerial->begin(9600);
    pinMode(SOFT_SERIAL_PIN_2, OUTPUT);
  }
#endif
#ifdef SOFT_SERIAL_PIN_8
  if(id == SOFT_SERIAL_PIN_2)
  {
    softSerial = new SoftwareSerial(SOFT_SERIAL_PIN_2, SOFT_SERIAL_PIN_2, false);
    port = softSerial;
    softSerial->begin(9600);
    pinMode(SOFT_SERIAL_PIN_2, OUTPUT);
  }
#endif
#ifdef SOFT_SERIAL_PIN_9
  if(id == SOFT_SERIAL_PIN_2)
  {
    softSerial = new SoftwareSerial(SOFT_SERIAL_PIN_2, SOFT_SERIAL_PIN_2, false);
    port = softSerial;
    softSerial->begin(9600);
    pinMode(SOFT_SERIAL_PIN_2, OUTPUT);
  }
#endif
#ifdef SOFT_SERIAL_PIN_10
  if(id == SOFT_SERIAL_PIN_2)
  {
    softSerial = new SoftwareSerial(SOFT_SERIAL_PIN_2, SOFT_SERIAL_PIN_2, false);
    port = softSerial;
    softSerial->begin(9600);
    pinMode(SOFT_SERIAL_PIN_2, OUTPUT);
  }
#endif
#ifdef SOFT_SERIAL_PIN_11
  if(id == SOFT_SERIAL_PIN_2)
  {
    softSerial = new SoftwareSerial(SOFT_SERIAL_PIN_2, SOFT_SERIAL_PIN_2, false);
    port = softSerial;
    softSerial->begin(9600);
    pinMode(SOFT_SERIAL_PIN_2, OUTPUT);
  }
#endif
#ifdef SOFT_SERIAL_PIN_12
  if(id == SOFT_SERIAL_PIN_2)
  {
    softSerial = new SoftwareSerial(SOFT_SERIAL_PIN_2, SOFT_SERIAL_PIN_2, false);
    port = softSerial;
    softSerial->begin(9600);
    pinMode(SOFT_SERIAL_PIN_2, OUTPUT);
  }
#endif
}

void FrSkyTelemetryLRS::setFgsData(float fuel)
{
  enabledSensors |= SENSOR_FGS;
  FrSkyTelemetryLRS::fuel = (uint16_t)round(fuel);
}

void FrSkyTelemetryLRS::setFlvsData(float cell1, float cell2, float cell3, float cell4, float cell5, float cell6,
                                 float cell7, float cell8, float cell9, float cell10, float cell11, float cell12)
{
  enabledSensors |= SENSOR_FLVS;
  // DEVIATION FROM SPEC: in reality cells are numbered from 0 not from 1 like in the FrSky protocol spec
  FrSkyTelemetryLRS::cell[0] = 0x0000 | (uint16_t)round(cell1 * 500.0);
  FrSkyTelemetryLRS::cell[1]  = 0x0000;
  FrSkyTelemetryLRS::cell[2]  = 0x0000;
  FrSkyTelemetryLRS::cell[3]  = 0x0000;
  FrSkyTelemetryLRS::cell[4]  = 0x0000;
  FrSkyTelemetryLRS::cell[5]  = 0x0000;
  FrSkyTelemetryLRS::cell[6]  = 0x0000;
  FrSkyTelemetryLRS::cell[7]  = 0x0000;
  FrSkyTelemetryLRS::cell[8]  = 0x0000;
  FrSkyTelemetryLRS::cell[9]  = 0x0000;
  FrSkyTelemetryLRS::cell[10]  = 0x0000;
  FrSkyTelemetryLRS::cell[11]  = 0x0000;
  
  if(cell2  != 0) FrSkyTelemetryLRS::cell[1]  = 0x1000 | (uint16_t)round(cell2  * 500.0);
  if(cell3  != 0) FrSkyTelemetryLRS::cell[2]  = 0x2000 | (uint16_t)round(cell3  * 500.0);
  if(cell4  != 0) FrSkyTelemetryLRS::cell[3] = 0x3000 | (uint16_t)round(cell4  * 500.0);
  if(cell5  != 0) FrSkyTelemetryLRS::cell[4]  = 0x4000 | (uint16_t)round(cell5  * 500.0);
  if(cell6  != 0) FrSkyTelemetryLRS::cell[5]  = 0x5000 | (uint16_t)round(cell6  * 500.0);
  if(cell7  != 0) FrSkyTelemetryLRS::cell[6]  = 0x6000 | (uint16_t)round(cell7  * 500.0);
  if(cell8  != 0) FrSkyTelemetryLRS::cell[7]  = 0x7000 | (uint16_t)round(cell8  * 500.0);
  if(cell9  != 0) FrSkyTelemetryLRS::cell[8]  = 0x8000 | (uint16_t)round(cell9  * 500.0);
  if(cell10 != 0) FrSkyTelemetryLRS::cell[9]  = 0x9000 | (uint16_t)round(cell10 * 500.0);
  if(cell11 != 0) FrSkyTelemetryLRS::cell[10] = 0xA000 | (uint16_t)round(cell11 * 500.0);
  if(cell12 != 0) FrSkyTelemetryLRS::cell[11] = 0xB000 | (uint16_t)round(cell12 * 500.0);
}

void FrSkyTelemetryLRS::setFasData(float current, float voltage)
{
  enabledSensors |= SENSOR_FAS;
  // DEVIATION FROM SPEC: FrSky protocol spec suggests 0.5 ratio, but in reality this ratio is 0.5238 (based on the information from internet).
  voltage *= 0.5238;
  FrSkyTelemetryLRS::voltageBD = (uint16_t)voltage;
  FrSkyTelemetryLRS::voltageAD = (uint16_t)round((voltage - voltageBD) * 10.0);
  FrSkyTelemetryLRS::current = (uint16_t)round(current * 10.0);
}

void FrSkyTelemetryLRS::setFvasData(float alt)
{
  enabledSensors |= SENSOR_FVAS;
  FrSkyTelemetryLRS::altBD = (int16_t)alt;
  FrSkyTelemetryLRS::altAD = abs((int16_t)round((alt - FrSkyTelemetryLRS::altBD) * 100.0));
}

void FrSkyTelemetryLRS::setGpsData(float lat, float lon, float alt, float speed, float cog, uint16_t year, uint8_t month, uint8_t day, uint8_t hour, uint8_t minute, uint8_t second)
{
  enabledSensors |= SENSOR_GPS;
  FrSkyTelemetryLRS::latNS = (uint16_t)(lat < 0 ? 'S' : 'N'); if(lat < 0) lat = -lat;
  FrSkyTelemetryLRS::latBD = (uint16_t)lat;
  lat = (lat - (float)FrSkyTelemetryLRS::latBD) * 60.0;
  FrSkyTelemetryLRS::latBD = FrSkyTelemetryLRS::latBD * 100 + (uint16_t)lat;
  FrSkyTelemetryLRS::latAD = (uint16_t)round((lat - (uint16_t)lat) * 10000.0);
  FrSkyTelemetryLRS::lonEW = (uint16_t)(lon < 0 ? 'W' : 'E');  if(lon < 0) lon = -lon;
  FrSkyTelemetryLRS::lonBD = (uint16_t)lon; 
  lon = (lon - (float)FrSkyTelemetryLRS::lonBD) * 60.0;
  FrSkyTelemetryLRS::lonBD = FrSkyTelemetryLRS::lonBD * 100 + (uint16_t)lon;
  FrSkyTelemetryLRS::lonAD = (uint16_t)round((lon - (uint16_t)lon) * 10000.0);
  FrSkyTelemetryLRS::altBD = (int16_t)alt;
  FrSkyTelemetryLRS::altAD = abs((int16_t)round((alt - FrSkyTelemetryLRS::altBD) * 100.0));
  speed *= 1.94384; // Convert m/s to knots
  FrSkyTelemetryLRS::speedBD = (uint16_t)speed;
  FrSkyTelemetryLRS::speedAD = (uint16_t)round((speed - FrSkyTelemetryLRS::speedBD) * 100.0);
  FrSkyTelemetryLRS::cogBD = (uint16_t)cog;
  FrSkyTelemetryLRS::cogAD = (uint16_t)round((cog - FrSkyTelemetryLRS::cogBD) * 100.0);
  FrSkyTelemetryLRS::year  = (uint16_t)(year);
  FrSkyTelemetryLRS::dayMonth = (uint16_t)day; FrSkyTelemetryLRS::dayMonth <<= 8; FrSkyTelemetryLRS::dayMonth |= (uint16_t)month;
  FrSkyTelemetryLRS::hourMinute = (uint16_t)hour; FrSkyTelemetryLRS::hourMinute <<= 8; FrSkyTelemetryLRS::hourMinute |= (uint16_t)minute;
  FrSkyTelemetryLRS::second = (uint16_t)second;
}

void FrSkyTelemetryLRS::setTasData(float accX, float accY, float accZ)
{
  enabledSensors |= SENSOR_TAS;
  FrSkyTelemetryLRS::accX = (int16_t)round(accX * 1000.0);
  FrSkyTelemetryLRS::accY = (int16_t)round(accY * 1000.0);
  FrSkyTelemetryLRS::accZ = (int16_t)round(accZ * 1000.0);
}

void FrSkyTelemetryLRS::setTemsData(float t1, float t2)
{
  enabledSensors |= SENSOR_TEMS;
  FrSkyTelemetryLRS::t1 = (int16_t)round(t1);
  FrSkyTelemetryLRS::t2 = (int16_t)round(t2);
}

void FrSkyTelemetryLRS::setRpmsData(float rpm)
{
  enabledSensors |= SENSOR_RPMS;
  FrSkyTelemetryLRS::rpm = (uint16_t)round(rpm / 30.0);
}

void FrSkyTelemetryLRS::sendSeparator()
{
  if(port != NULL)
  {
    port->write(0x5E);
  }
}

void FrSkyTelemetryLRS::sendByte(uint8_t byte)
{
  if(port != NULL)
  {
    if(byte == 0x5E) // use 5D 3E sequence instead of 5E to distinguish between separator character and real data
    {
      port->write(0x5D);
      port->write(0x3E);
    }
    else if(byte == 0x5D) // use 5D 3D sequence instead of 5D to distinguish between stuffing character and real data
    {
      port->write(0x5D);
      port->write(0x3D);
    }
    else
    {
      port->write(byte);
    }
    if(port != NULL) port->flush();
  }
  else
  {
    Serial.println("no serial port defined");
  }
}

void FrSkyTelemetryLRS::sendData(uint8_t dataId, uint16_t data, bool bigEndian)
{
  sendSeparator();
  sendByte(dataId);
  uint8_t *bytes = (uint8_t*)&data;
  if(bigEndian == false)
  {
    sendByte(bytes[0]);
    sendByte(bytes[1]);
  }
  else
  {
    sendByte(bytes[1]);
    sendByte(bytes[0]);
  }
  if(port != NULL) port->flush();
}

bool FrSkyTelemetryLRS::sendFasData()
{
  bool enabled = enabledSensors & SENSOR_FAS;
  if(enabled == true)
  {
    sendData(0x28, current);
    sendData(0x3A, voltageBD);
    sendData(0x3B, voltageAD);
  }
  return enabled;
}

bool FrSkyTelemetryLRS::sendFgsData()
{
  bool enabled = enabledSensors & SENSOR_FGS;
  if(enabled == true)
  {
    sendData(0x04, fuel);
  }
  return enabled;
}

bool FrSkyTelemetryLRS::sendFlvsData()
{
  bool enabled = enabledSensors & SENSOR_FLVS;
  if(enabled == true)
  {
    // Only send one cell at a time
    if((cell[cellIdx] == 0) || (cellIdx == 12)) cellIdx = 0;
    sendData(0x06, cell[cellIdx], true);  
    cellIdx++;
  }
  return enabled;
}

bool FrSkyTelemetryLRS::sendFvasData()
{
  bool enabled = enabledSensors & SENSOR_FVAS;
  if(enabled == true)
  {
    sendData(0x10, altBD);  
    sendData(0x21, altAD);  
  }
  return enabled;
}

bool FrSkyTelemetryLRS::sendGpsData()
{
  bool enabled = enabledSensors & SENSOR_GPS;
  if(enabled == true)
  {
    sendData(0x01, gpsAltBD);  
    sendData(0x09, gpsAltAD);  
    sendData(0x11, speedBD);  
    sendData(0x19, speedAD);  
    sendData(0x12, lonBD); // DEVIATION FROM SPEC: FrSky protocol spec says lat shall be sent as big endian, but it reality little endian is expected
    sendData(0x1A, lonAD); // DEVIATION FROM SPEC: FrSky protocol spec says lat shall be sent as big endian, but it reality little endian is expected
    sendData(0x22, lonEW); // DEVIATION FROM SPEC: FrSky protocol spec says lon shall be sent as big endian, but it reality little endian is expected 
    sendData(0x13, latBD); // DEVIATION FROM SPEC: FrSky protocol spec says lon shall be sent as big endian, but it reality little endian is expected
    sendData(0x1B, latAD);  
    sendData(0x23, latNS);  
    sendData(0x14, cogBD);  
    sendData(0x1C, cogAD);  
  }
  return enabled;
}

bool FrSkyTelemetryLRS::sendDateTimeData()
{
  bool enabled = enabledSensors & SENSOR_GPS;
  if(enabled == true)
  {
    sendData(0x15, dayMonth, true);  
    sendData(0x16, year);  
    sendData(0x17, hourMinute, true);  
    sendData(0x18, second);  
  }
  return enabled;
}

bool FrSkyTelemetryLRS::sendTasData()
{
  bool enabled = enabledSensors & SENSOR_TAS;
  if(enabled == true)
  {
    sendData(0x24, accX);  
    sendData(0x25, accY);  
    sendData(0x26, accZ);  
  }
  return enabled;
}

bool FrSkyTelemetryLRS::sendTemsData()
{
  bool enabled = enabledSensors & SENSOR_TEMS;
  if(enabled == true)
  {
    sendData(0x02, t1);  
    sendData(0x05, t2);
  }
  return enabled;
}
   
bool FrSkyTelemetryLRS::sendRpmsData()
{
  bool enabled = enabledSensors & SENSOR_RPMS;
  if(enabled == true)
  {
    sendData(0x03, rpm);
  }
  return enabled;
}

void FrSkyTelemetryLRS::sendFrame1()
{
  bool result = false;
  result  = sendFasData();
  result |= sendFlvsData();
  result |= sendFvasData();
  result |= sendTasData();
  result |= sendTemsData();
  result |= sendRpmsData();
  if (result == true) sendSeparator();
}

void FrSkyTelemetryLRS::sendFrame2()
{
  bool result = false;
  result  = sendFgsData();
  result |= sendGpsData();
  if (result == true) sendSeparator();
}

void FrSkyTelemetryLRS::sendFrame3()
{
  bool result = false;
  result = sendDateTimeData();
  if (result == true) sendSeparator();
}

void FrSkyTelemetryLRS::send()
{
  uint32_t currentTime = millis(); 
  if(currentTime > frame3Time) // Sent every 5s (5000ms)
  {
    frame3Time = currentTime + 5000;
    frame2Time = currentTime + 200; // Postpone frame 2 to next cycle
    frame1Time = currentTime + 200; // Postpone frame 1 to next cycle
    sendFrame3();
  }
  else if(currentTime > frame2Time) // Sent every 1s (1000ms)
  {
    frame2Time = currentTime + 2000;
    frame1Time = currentTime + 200; // Postpone frame 1 to next cycle
    sendFrame2();
  } 
  else if(currentTime > frame1Time) // Sent every 200ms
  {
    frame1Time = currentTime + 200;
    sendFrame1();
  }
}
